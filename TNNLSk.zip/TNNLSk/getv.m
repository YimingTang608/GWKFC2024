function [a] = getv(z,ord,idx)
N=length(z);
former=z(idx(1));
latter=sum(z(idx(2:N)));
fins=former-latter;
r_idx=1;
fin=1e5;
r=1;
while r<N
    fin_new=abs(former-latter);
    if fin_new<=fin
        fin=fin_new;
        fins=former-latter;
        r_idx=r;
    end
    r=r+1;
    former=former+z(idx(r));
    latter=latter-z(idx(r));
end
if fins<0
    a=ord(r_idx);
elseif fins>0
    a=ord(r_idx+1);
else
    a=(ord(r_idx)+ord((r_idx+1)))/2;
end