function [numrep] = RSGG(data,w,M)
[N,D]=size(data);
numrep=zeros(M,D);
disM=pdist2(data,data,'euclidean');
mdj = max(max(disM));
r=mdj/(M*w);
usedisM=disM-r;
usedisM(usedisM>0)=0;
density=-sum(usedisM,2);
[~,idx]=sort(density,'descend');
mindis=zeros(N,1);
numrep(1,:)=data(idx(1),:);
numrep_idx=idx(1);
for i=2:N
    mindis(idx(i))=min(disM(idx(i),idx(1:(i-1))));
end
tao=mindis.*density;
[~,idx]=sort(tao,'descend');
i=2;j=1;
while i<=M && j<=N
    if min(disM(idx(j),numrep_idx(1:i-1)))>=r
        numrep(i,:)=data(idx(j),:);
        numrep_idx(i)=idx(j);
        i=i+1;
    end
    j=j+1;
end
end