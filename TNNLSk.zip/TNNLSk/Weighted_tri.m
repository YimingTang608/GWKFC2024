function [w_s_int] = Weighted_tri(data,lb,rb,numrep)
[N,D]=size(data);
[Vnum,~]=size(lb);
w_s_int=zeros([1 Vnum]);
fo=max(data,[],1)-min(data,[],1);

for i=1:Vnum
    datain=data((sum(data>=lb(i,:),2)==D)&(sum(data<=rb(i,:),2)==D),:);
    [n,~]=size(datain);
    Psl=zeros([n D]);
    for ii=1:n
        for jj=1:D
            if datain(ii,jj)>=numrep(i,:)
                Psl(ii,jj)=(rb(i,jj)-datain(ii,jj))/(rb(i,jj)-numrep(i,jj));
            else
                Psl(ii,jj)=(datain(ii,jj)-lb(i,jj))/(numrep(i,jj)-lb(i,jj));
            end
        end
    end
    Ps=sum(min(Psl,[],2));
    TY=2-((rb(i,:)-lb(i,:))./(2.*fo));
    w_s_int(i)=(Ps/N)*(prod(TY)^(1/D));
end
w_s_int=w_s_int./max(w_s_int);
end