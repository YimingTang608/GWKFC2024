function [U,V_l,V_r,V_n] = GWKFC_tri(lb,rb,numrep,m,c,itermax,th,sigma,w_s_tri)
[N,~]=size(lb);

iter=0;

inc=randperm(N,c);
V_l=lb(inc,:);
V_r=rb(inc,:);
V_n=numrep(inc,:);

while iter<itermax
    dl = pdist2(lb,V_l,'squaredeuclidean');
    dr = pdist2(rb,V_r,'squaredeuclidean');
    dn = pdist2(numrep,V_n,"squaredeuclidean");
    K=exp(-((dl+dr+dn)./(2*sigma^2)));

    U=(1-K).^(1/(1-m));
    U=U./sum(U,2);
    for i=1:c
        U(inc(i),i)=1;
    end

    tem=w_s_tri.*(U.^m)'.*K';
    V_l_new=tem*lb./sum(tem,2);
    V_r_new=tem*rb./sum(tem,2);
    V_n_new=tem*numrep./sum(tem,2);

    err=norm((V_l_new-V_l),"fro")+norm((V_r_new-V_r),"fro")+norm((V_n_new-V_n),"fro");
    V_l=V_l_new;
    V_r=V_r_new;
    V_n=V_n_new;
    if err<th
        break;
    end

    iter=iter+1;
end
end