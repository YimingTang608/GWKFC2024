function [w_s_int,idx] = Weighted_int(data,lb,rb)
[N,D]=size(data);
[Vnum,~]=size(lb);
w_s_int=zeros([1 Vnum]);
idx=zeros([N 1]);
fo=max(data,[],1)-min(data,[],1);
for i=1:Vnum
    datain=data((sum(data>=lb(i,:),2)==D)&(sum(data<=rb(i,:),2)==D),:);
    [~,Loc] = ismember(datain, data, 'rows');
    idx(Loc)=1;
    Ps=length(Loc);
    TY=2-((rb(i,:)-lb(i,:))./fo);
    w_s_int(i)=(Ps/N)*(prod(TY)^(1/D));
end

w_s_int=w_s_int./max(w_s_int);
end