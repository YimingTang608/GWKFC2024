clc;
clear;

dataset_dir = "./dataset/";
filename = "data_11.txt";
data = load(dataset_dir+filename);
data=datanorm(data,'var');
[N,D]=size(data);

rate=0.2;
M=floor(rate*N);
w=2;
numrep=RSGG(data,w,M);

%Interval data
fo=1.0;
[lb,rb]=Generate_int(data,numrep,fo);
[w_s_int,idx] = Weighted_int(data,lb,rb);

c=3;
m=1.41;
itermax=100;
th=1e-8;
sigma=2;
[U,V_l,V_r]=GWKFC_int(lb,rb,m,c,itermax,th,sigma,w_s_int);

R = RE_int(U,V_l,V_r,lb,rb,m);
fprintf("RE = %.2f\n",R);

%Triangular data
% fo2=0.3;
% p=100;
% [lb,rb]=Generate_tri(data,numrep,fo2,p);
% [w_s_tri] = Weighted_tri(data,lb,rb,numrep);
%  
% c=6;
% m=1.11;
% itermax=100;
% th=1e-8;
% sigma=2;
% [U,V_l,V_r,V_n]=GWKFC_tri(lb,rb,numrep,m,c,itermax,th,sigma,w_s_tri);
% 
% R2 = RE_tri(U,V_l,V_r,V_n, numrep,lb,rb,m);
% fprintf("RE = %.2f\n",R2);
