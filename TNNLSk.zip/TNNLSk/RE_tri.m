function [RE] = RE_tri(U,Vl,Vr,Vn,numrep,lb,rb,m)
Um = U.^m;
sumU=sum(Um,2);
lb_re=Um*Vl./sumU;
rb_re=Um*Vr./sumU;
vn_re=Um*Vn./sumU;
RE = norm((lb_re-lb),"fro")^2+norm((rb_re-rb),"fro")^2+norm((vn_re-numrep),"fro")^2;
end