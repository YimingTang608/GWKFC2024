function [lb,rb] = Generate_tri(data,numrep,fo,p)
%Obtain triangular boundary
[N,D]=size(data);
[n,~]=size(numrep);
lb=zeros(n,D);
rb=zeros(n,D);
for j=1:D
    [ord,~]=sort(data(:,j));
    for i=1:n
        boundaryleft=linspace(ord(1),numrep(i,j),p);
        boundaryright=linspace(numrep(i,j),ord(N),p);
        %QLo=zeros(1,p);
        QL=0;
        QR=0;
        for b = 1:p
            Qnew=get_tri_pjgQ(ord,numrep(i,j),boundaryleft(b),fo,'left');
            if Qnew>QL
                lb(i,j)=boundaryleft(b);
                QL=Qnew;
            end
            %QLo(b)=get_tri_pjgQ(ord,numrep(i,j),boundaryleft(b),fo,'left');
        end
        % [~,idx]=max(QLo);
        % lb(i,j)=boundaryleft(idx);
        for b = 1:p
            Qnew=get_tri_pjgQ(ord,numrep(i,j),boundaryright(b),fo,'right');
            if Qnew>=QR
                rb(i,j)=boundaryright(b);
                QR=Qnew;
            end
        end
    end
end
end