function [Q] = get_tri_pjgQ(ord,betla,boundary,fo,direction)
if betla==boundary
    Q=1/length(ord);
elseif strcmp(direction,'right')
    sp=exp(-(boundary-betla)/(2*fo));
    covpoint=ord((ord>=betla)&(ord<=boundary));
    cov=sum(boundary-covpoint)/(length(ord)*(boundary-betla));
    Q=sp*cov;
elseif strcmp(direction,'left')
    sp=exp(-(betla-boundary)/(2*fo));
    covpoint=ord((ord<=betla)&(ord>=boundary));
    cov=sum(covpoint-boundary)/(length(ord)*(betla-boundary));
    Q=sp*cov;
end
end