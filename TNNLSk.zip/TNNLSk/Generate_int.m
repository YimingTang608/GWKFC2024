function [lb,rb]=Generate_int(data,numrep,fo)
%Obtain interval boundary
[N,D]=size(data);
[n,~]=size(numrep);
lb=zeros(n,D);
rb=zeros(n,D);
for j=1:D
    [ord,~]=sort(data(:,j));
    for i=1:n
        QL=0;
        QR=0;
        cover=1;
        lrd=ord(ord<=numrep(i,j));
        lbd=length(lrd);
        while lbd>=1%left boundary
            Qnew=(cover/N)*exp(-((numrep(i,j)-lrd(lbd))/fo));
            if Qnew>QL
                lb(i,j)=lrd(lbd);
                QL=Qnew;
            end
            lbd=lbd-1;
            cover=cover+1;
        end
        cover=1;
        rrd=ord(ord>=numrep(i,j));
        rbd=1;
        while rbd<=length(rrd)%right boundary
            Qnew=(cover/N)*exp(-((rrd(rbd)-numrep(i,j))/fo));
            if Qnew>QR
                rb(i,j)=rrd(rbd);
                QR=Qnew;
            end
            rbd=rbd+1;
            cover=cover+1;
        end
    end
end
end