function [U,V_l,V_r] = GWKFC_int(lb,rb,m,c,itermax,th,sigma,w_s_int)
[N,~]=size(lb);

iter=0;

inc=randperm(N,c);
V_l=lb(inc,:);
V_r=rb(inc,:);

while iter<itermax
    dl = pdist2(lb,V_l,'squaredeuclidean');
    dr = pdist2(rb,V_r,'squaredeuclidean');
    K=exp(-((dl+dr)./(2*sigma^2)));

    U=(1-K).^(1/(1-m));
    U=U./sum(U,2);
    for i=1:c
        U(inc(i),i)=1;
    end

    tem=w_s_int.*(U.^m)'.*K';
    V_l_new=tem*lb./sum(tem,2);
    V_r_new=tem*rb./sum(tem,2);

    err=norm((V_l_new-V_l),"fro")+norm((V_r_new-V_r),"fro");
    V_l=V_l_new;
    V_r=V_r_new;
    if err<th
        break;
    end

    iter=iter+1;
end
end