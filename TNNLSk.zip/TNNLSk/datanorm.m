function data=datanorm(data,method)
if strcmp(method,'range')
    data_min = min(data,[],1);
    data_max = max(data,[],1);
    data = (data-data_min)./(data_max-data_min);
elseif strcmp(method,'var')
    data = (data-mean(data))./std(data);
elseif strcmp(method,'kar')
    data = data./sum(data,1);
end