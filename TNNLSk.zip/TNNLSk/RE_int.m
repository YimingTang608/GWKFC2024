function [RE]=RE_int(U,Vl,Vb,lb,rb,m)
Um = U.^m;
sumU=sum(Um,2);
lb_re=Um*Vl./sumU;
rb_re=Um*Vb./sumU;
RE = norm((lb_re-lb),"fro")^2+norm((rb_re-rb),"fro")^2;
end